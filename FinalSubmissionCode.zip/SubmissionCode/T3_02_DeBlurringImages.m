%{
===========================================================================
Aim:
    Calculating MSE
===========================================================================
%}

%% Basic Setup
clc;clear; close all;

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur3x3/DeBlur3x3_BlindDeconv";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur3x3/DeBlur3x3_LucyRechardson";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)



fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur5x5/DeBlur5x5_BlindDeconv";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur5x5/DeBlur5x5_LucyRichardson";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)



fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur7x7/DeBlur_BlindDeconv";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur7x7/DeBlur_LucyRichardson";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)


fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur11x11/DeBlur11x11_BlindDeconv";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur11x11/DeBlur11x11_LucyRichardson";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)





fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")
fprintf("==========================================================================================\n")

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur15x15/DeBlur15x15_BlindDeconv";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)

%% Calculating MSE
image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur15x15/DeBlur15x15_LucyRichardson";
originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
[filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)



%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [filenames_in_path, mselist, psnrlist] = fetchmymse(image_directory_path, originalpath)
    % image_directory_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur3x3/DeBlur3x3_BlindDeconv";
    % originalpath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
    filenames_in_path = fgetImagePaths(image_directory_path);
    mselist = []; psnrlist = [];
    for i = 1:length(filenames_in_path)
        % reading image
        inputimage00 = im2double(imread(filenames_in_path(i)));
        [~, filename01, extension01] = fileparts(filenames_in_path(i));
    
        % reading original image
        inputimage01 = im2double(imread(fullfile(originalpath, filename01+extension01)));
    
        % calculating MSE
        mse00 = mean((inputimage00 - inputimage01(20:end-20,:,:)).^2, 'all');
    
        % appending to larger list
        mselist = [mselist; mse00];

        % appending to larger list
        psnrlist = [psnrlist; psnr(inputimage01(20:end-20,:,:), inputimage00)];
    
    end
end

function imagePaths = fgetImagePaths(directoryPath)
    % List all files in the directory
    files = dir(directoryPath);
    
    % Initialize an empty cell array to store image paths
    imagePaths = [];
    
    % Iterate through each file in the directory
    for i = 1:length(files)
        % Check if the file is an image (by checking the extension)
        [~, ~, ext] = fileparts(files(i).name);
        % List of common image extensions
        imageExtensions = {'.jpg', '.jpeg', '.png','.tif', '.gif', '.bmp'};
        
        % If the file has a valid image extension, add its full path to the imagePaths array
        if any(strcmpi(ext, imageExtensions))
            % Concatenate the directory path and file name to get the full path
            imagePath = fullfile(directoryPath, files(i).name);
            % Add the full path to the imagePaths array
            imagePaths = [imagePaths; string(imagePath)];
        end
    end
end
