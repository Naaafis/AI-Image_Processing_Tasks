function subdirectories = fgetSubdirectories(path)
    % List the contents of the directory
    contents = dir(path);

    % Initialize an empty cell array to store subdirectory names
    subdirectories = [];

    % Loop through each item in the directory
    for i = 1:length(contents)

        % Check if the item is a directory and not '.' or '..'
        if contents(i).isdir && ~strcmp(contents(i).name, '.') && ~strcmp(contents(i).name, '..')
            
            % Append the directory name to the cell array
            subdirectories = [subdirectories, string(contents(i).name)];
        end
    end
end