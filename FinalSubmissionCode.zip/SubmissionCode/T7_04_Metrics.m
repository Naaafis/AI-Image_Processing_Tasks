%{
===========================================================================
Aim:
    Calculating Metrics for
        1. Blind Deconvolution
        2. Lucy Richardson
        3. Reshift
        4. Dall-E Deblur
        5. Pix2Pix
        6. Dall-E (new images)
        7. Deep Learning Model
===========================================================================
%}

%% Basic Setup
clc; clear; close all;

%% First two paths
OriginalDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.05_Method_2ndOrder/GaussianNoise_MAP_lambda_0.05_Method/Gaussian_Variance=0";


%% getting the list of paths to original images
pathstooriginalimages = fgetImagePaths(OriginalDirectory);



%% ############################################ BLIND DECONV ################################################################################
"############################################ BLIND DECONV - Deblurring ################################################################################"
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: DeBlur_3x3_BlindDeconv
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur3x3/DeBlur3x3_BlindDeconv"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_5x5_BlindDeconv
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur5x5/DeBlur5x5_BlindDeconv"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_7x7_BlindDeconv
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur7x7/DeBlur7x7_BlindDeconv"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_11x11_BlindDeconv
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur11x11/DeBlur11x11_BlindDeconv"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_7x7_BlindDeconv
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur15x15/DeBlur15x15_BlindDeconv"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01]
metriclist = [metriclist; metriclist00]


%% ############################################ Lucy Richardson ################################################################################
"############################################ Lucy Richardson  - Deblurring ################################################################################"
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: DeBlur_3x3_LucyRichardson
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur3x3/DeBlur3x3_LucyRechardson"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_5x5_LucyRichardson
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur5x5/DeBlur5x5_LucyRichardson"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_7x7_LucyRichardson
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur7x7/DeBlur7x7_LucyRichardson"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_11x11_LucyRichardson
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur11x11/DeBlur11x11_LucyRichardson"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DeBlur_7x7_LucyRichardson
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur15x15/DeBlur15x15_LucyRichardson"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01]
metriclist = [metriclist; metriclist00]

%% ######################################### RESSHIFT ########################################################################################
" ######################################### RESSHIFT  - Deblurring ########################################################################################"
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: 
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/ResShift/Results"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar("/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/ResShift/InputImages/Original", inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01]
metriclist = [metriclist; metriclist00]

%% Directory: 
subdirectorytitles = []; metriclist = [];
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/MatlabDownsampled/31_coef_upsampled"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01]
metriclist = [metriclist; metriclist00]

%% Directory: 
subdirectorytitles = []; metriclist = [];
inputdirectory01 = "/Users/vrsreeganesh/Downloads/AI-Image_Processing_Tasks-main/UpconvertingTask/AI_Upsampled_Images"; 
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01]
metriclist = [metriclist; metriclist00]




%% ############################################ Dall-E DeBLUR ################################################################################
"############################################ Dall-E DeBLUR ################################################################################"
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: DallE Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/FromNafis/Deblurring/Blur_3x3_dalle2_deblurred_Downconverted";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DallE Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/FromNafis/Deblurring/Blur_7x7_dalle2_deblurred_Downconverted";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: DallE Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/FromNafis/Deblurring/Blur_15x15_dalle2_deblurred_Downconverted";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% ########################################## PIX2PIX Deblurring ################################################################################
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: Pix2Pix Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/pix2pix/Blur_3x3";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Pix2Pix Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/pix2pix/Blur_5x5";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Pix2Pix Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/pix2pix/Blur_7x7";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Pix2Pix Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/pix2pix/Blur_11x11";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Pix2Pix Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/pix2pix/Blur_15x15";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00]

%% ########################################## Dall-E Deblurring ################################################################################
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_3x3_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_5x5_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_7x7_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_11x11_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Deblur
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_15x15_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00]


%% ########################################## DEEP LEARNING DENOISING ################################################################################
%% The final destination
subdirectorytitles = []; metriclist = [];

%% Directory: Denoise
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_3x3_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Denoise
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_5x5_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Denoise
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_7x7_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Denoise
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_11x11_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00];

%% Directory: Denoise
inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Dalle2_Deblurred_special_prompt/Blur_15x15_dalle2_deblurred";
[mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, inputdirectory01);
metriclist00 = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
subdirectorytitles = [subdirectorytitles; inputdirectory01];
metriclist = [metriclist; metriclist00]


% % fplotmsepsnrssim(1, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur5x5"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory)
% % fplotmsepsnrssim(2, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeBlurredImages_Matlab/DeBlur7x7"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory)
% % fplotmsepsnrssim(3, metriclist);















% %% Directory: Wiener
% subdirectorytitles = []; metriclist = []; 
% inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener3x3Method"; 
% [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(1, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener5x5Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(2, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener7x7Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(3, metriclist);


% 
% %% Directory: Median
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Median7x7Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(4, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Median5x5Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(5, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Median3x3Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(6, metriclist);
% 
% 
% 
% %% Directory: Mean
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Mean7x7Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(7, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Mean5x5Method";[subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(8, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Mean3x3Method";[subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(9, metriclist);
% 
% 
% 
% 
% %% Directory: Map first order
% 
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.5_Method"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(10, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.1_Method";[subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(11, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.05_Method";[subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(12, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.01_Method";[subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% 
% 
% 
% %% Directory: Map Second Order
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.5_Method_2ndOrder"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(13, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.1_Method_2ndOrder"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(14, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.05_Method_2ndOrder"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(15, metriclist);
% subdirectorytitles = []; metriclist = []; inputdirectory01 = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.01_Method_2ndOrder"; [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory);
% fplotmsepsnrssim(16, metriclist);
% 
% 
% %% Saving CSV
% % bruhtable = table(subdirectorytitles, metriclist(:,1), metriclist(:,2), metriclist(:,3), metriclist(:,4), metriclist(:,5), metriclist(:,6));
% % row_names = ["method", "mse_mean","mse_var","psnr_mean","psnr_var","ssim_mean","ssim_var"];
% % bruhtable.Properties.VariableNames = row_names;
% % writetable(bruhtable, "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Results/t00.csv");
% % 
% % %% Saving Mat Files
% % save("/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Results/subdirectorytitles00.mat", "subdirectorytitles", "metriclist");
% 
% 
% %% Making Plots
% figure(1);
% 
% subdirectorytitles
% % metriclist


%% Functions
function [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, ParentDenoisedDirectory)
    [mselist00, psnrlist00, ssimlist00] = fCalculateMatrics(OriginalDirectory, ParentDenoisedDirectory);
    mse00_mean = mean(mselist00); psnr00_mean = mean(psnrlist00); ssim_mean = mean(ssimlist00);
    mse00_var = var(mselist00); psnr00_var = var(psnrlist00); ssim_var = var(ssimlist00);
end

function [mselist, psnrlist, ssimlist] = fCalculateMatrics(originaldirectorypath, processeddirectorypath)
    %% Reading files and calculating SSIM and PSNR
    filenames_in_path = fgetImagePaths(processeddirectorypath);
    mselist = []; psnrlist = [];ssimlist = []; 
    for i = 1:length(filenames_in_path)
        % reading image
        inputimage00 = im2double(imread(filenames_in_path(i)));
        [~, filename01, extension01] = fileparts(filenames_in_path(i));

        
    
        % reading original image
        inputimage01 = im2double(imread(fullfile(originaldirectorypath, filename01+extension01)));
        '================================================'
        filenames_in_path(i)
        size(inputimage00)
        size(inputimage01)
        if size(inputimage01,1)~=size(inputimage00,1)
            inputimage01 = inputimage01(20:end-20,:,:); % done cause the processed image wasn't the exact same dimensions
        end
    
        % % % plotting the images
        % % subplot(2,1,1); imshow(inputimage00);
        % % subplot(2,1,2); imshow(inputimage01);
        % 
        % '================================================'
        % filenames_in_path(i)
        % size(inputimage00)
        % size(inputimage01)

        if size(inputimage00,3)~=size(inputimage01,3)
            continue
        end
    
        % calculating MSE
        mse00 = mean((inputimage00 - inputimage01).^2, 'all');
    
        % appending to larger list
        mselist = [mselist; mse00];
    
        % appending to larger list
        psnrlist = [psnrlist; psnr(inputimage00, inputimage01)];
    
        % calculating SSIM values between the two
        ssimlist = [ssimlist; ssim(inputimage00, inputimage01)];
    
    end

end
function imagePaths = fgetImagePaths(directoryPath)
    % List all files in the directory
    files = dir(directoryPath);
    
    % Initialize an empty cell array to store image paths
    imagePaths = [];
    
    % Iterate through each file in the directory
    for i = 1:length(files)
        % Check if the file is an image (by checking the extension)
        [~, ~, ext] = fileparts(files(i).name);
        % List of common image extensions
        imageExtensions = {'.jpg', '.jpeg', '.png','.tif', '.gif', '.bmp'};
        
        % If the file has a valid image extension, add its full path to the imagePaths array
        if any(strcmpi(ext, imageExtensions))
            % Concatenate the directory path and file name to get the full path
            imagePath = fullfile(directoryPath, files(i).name);
            % Add the full path to the imagePaths array
            imagePaths = [imagePaths; string(imagePath)];
        end
    end
end

function [subdirectorytitles, metriclist] = f00(inputdirectory01, subdirectorytitles, metriclist, OriginalDirectory)
    
    %  getting their full name
    listofsubdirectories01 = fgetSubdirectories(inputdirectory01);
    for i01 = 1:length(listofsubdirectories01)
        listofsubdirectories01(i01) = fullfile(inputdirectory01, listofsubdirectories01(i01));
    end
    
    % going through each subdirectory
    for i01 = 1:length(listofsubdirectories01)
    
        inputdirectory00 = listofsubdirectories01(i01);
        listofsubdirectories00 = fgetSubdirectories(inputdirectory00);
        for i00 = 1:length(listofsubdirectories00)
            listofsubdirectories00(i00) = fullfile(inputdirectory00, listofsubdirectories00(i00));
        end
        
        
        for i00 = 1:length(listofsubdirectories00)
            % choose a subdirectory
            subdirectory00 = listofsubdirectories00(i00);
        
            % list images in the subdirectory
            imagesinsubdirectory00 = fgetImagePaths(subdirectory00);
        
            % getting the metrics
            [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var] = fgetmeanandvar(OriginalDirectory, subdirectory00);
        
            % storing the values
            bruh = [mse00_mean,mse00_var,psnr00_mean,psnr00_var,ssim_mean,ssim_var];
            metriclist = [metriclist; bruh];
            subdirectorytitles = [subdirectorytitles; subdirectory00];
        end
    end
end

function fplotmsepsnrssim(figurenumber, metriclist)
    figure(figurenumber);
    subplot(3,3,1); plot(metriclist(1:11,1)); title("MSE");  subplot(3,3,4); plot(metriclist(12:22,1)); title("MSE");  subplot(3,3,7); plot(metriclist(23:33,1)); title("MSE");  % the mse errors
    subplot(3,3,2); plot(metriclist(1:11,3)); title("PSNR"); subplot(3,3,5); plot(metriclist(12:22,3)); title("PSNR"); subplot(3,3,8); plot(metriclist(23:33,3)); title("PSNR"); % the mse errors
    subplot(3,3,3); plot(metriclist(1:11,5)); title("SSIM"); subplot(3,3,6); plot(metriclist(12:22,5)); title("SSIM"); subplot(3,3,9); plot(metriclist(23:33,5)); title("SSIM"); % the mse errors
end
