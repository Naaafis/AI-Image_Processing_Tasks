%{
===========================================================================
Aim: Denoising Using MAP
Notes:
    We start with the noisy image, and do some iterations. 
===========================================================================
%}


%% Basic Setup
clc; clear; close all; 

%% Using Median Method to Denoise Gaussian Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/GaussianNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener3x3Method/GaussianNoise_Wiener3x3Method";

% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end

bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fwiener3x3DenoiseAndWrite(input_directory_path, output_directory_path);
end

%% Using Median Method to Denoise Salt and Pepper Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SaltAndPepperNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener3x3Method/SaltAndPepperNoise_Wiener3x3Method";

% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end

bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fwiener3x3DenoiseAndWrite(input_directory_path, output_directory_path);
end

%% Using Median Method to Denoise Speckle Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SpeckleNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/Wiener3x3Method/SpeckleNoise_Wiener3x3Method";

% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end

bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fwiener3x3DenoiseAndWrite(input_directory_path, output_directory_path);
end





%% Functions
function imagePaths = fgetImagePaths(directoryPath)
    % List all files in the directory
    files = dir(directoryPath);
    
    % Initialize an empty cell array to store image paths
    imagePaths = [];
    
    % Iterate through each file in the directory
    for i = 1:length(files)
        % Check if the file is an image (by checking the extension)
        [~, ~, ext] = fileparts(files(i).name);
        % List of common image extensions
        imageExtensions = {'.jpg', '.jpeg', '.png','.tif', '.gif', '.bmp'};
        
        % If the file has a valid image extension, add its full path to the imagePaths array
        if any(strcmpi(ext, imageExtensions))
            % Concatenate the directory path and file name to get the full path
            imagePath = fullfile(directoryPath, files(i).name);
            % Add the full path to the imagePaths array
            imagePaths = [imagePaths; string(imagePath)];
        end
    end
end

function fwiener3x3DenoiseAndWrite(inputfilepath, directorytowriteto)
    filesinpath = fgetImagePaths(inputfilepath);
    % going through each image
    for i = 1:length(filesinpath)
        
        % read image, convert to double
        inputimage = im2double(imread(filesinpath(i)));
    
        % wiener-filtering
        result00 = zeros(size(inputimage));
        for depthindex = 1:size(inputimage,3)
            result00(:,:,depthindex) = wiener2(inputimage(:,:,depthindex), [3,3]);
        end
        

        % result00 = wiener2(inputimage, [5,5]);
        % result00 = wiener2(inputimage, [7,7]);
    
        % saving to path
        [~, basename00, extension00] = fileparts(filesinpath(i));
        outputfilename = fullfile(directorytowriteto, basename00+extension00);
        imwrite(result00, outputfilename);
    
    
    end

end
function subdirectories = getSubdirectories(path)
    % List the contents of the directory
    contents = dir(path);

    % Initialize an empty cell array to store subdirectory names
    subdirectories = [];

    % Loop through each item in the directory
    for i = 1:length(contents)

        % Check if the item is a directory and not '.' or '..'
        if contents(i).isdir && ~strcmp(contents(i).name, '.') && ~strcmp(contents(i).name, '..')
            
            % Append the directory name to the cell array
            subdirectories = [subdirectories, string(contents(i).name)];
        end
    end
end





























































