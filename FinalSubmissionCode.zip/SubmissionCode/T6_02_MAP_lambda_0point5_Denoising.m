%{
===========================================================================
Aim: Denoising Using Wiener Filtering
Notes:
    We start with the noisy image, and do some iterations. 
===========================================================================
%}

%% Basic Setup
clc; clear; close all; 

%% Using Median Method to Denoise Gaussian Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/GaussianNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.5_Method/GaussianNoise_MAP_lambda_0.5_Method";

% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end

bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fmapDenoiseAndWrite(input_directory_path, output_directory_path);
end

%% Using Median Method to Denoise Salt and Pepper Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SaltAndPepperNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.5_Method/SaltAndPepper_MAP_lambda_0.5_Method";
% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end
bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fmapDenoiseAndWrite(input_directory_path, output_directory_path);
end

%% Using Median Method to Denoise Speckle Noise
ParentNoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SpeckleNoise";
ParentDenoisedDirectory = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/DeNoisedImages/MAP_lambda_0.5_Method/SpeckleNoise_MAP_lambda_0.5_Method";
% creating output directory path if it doesn't exist
if ~exist(ParentDenoisedDirectory , 'dir')
    % If it doesn't exist, create it
    mkdir(ParentDenoisedDirectory );
end
bruh = getSubdirectories(ParentNoisedDirectory);

for i = 1:length(bruh)
    sub00 = bruh(i);
    input_directory_path = fullfile(ParentNoisedDirectory, sub00);
    output_directory_path = fullfile(ParentDenoisedDirectory, sub00);

    % creating output directory path if it doesn't exist
    if ~exist(output_directory_path , 'dir')
        % If it doesn't exist, create it
        mkdir(output_directory_path );
    end

    % path to input directory
    fmapDenoiseAndWrite(input_directory_path, output_directory_path);
end





%% Functions
function imagePaths = fgetImagePaths(directoryPath)
    % List all files in the directory
    files = dir(directoryPath);
    
    % Initialize an empty cell array to store image paths
    imagePaths = [];
    
    % Iterate through each file in the directory
    for i = 1:length(files)
        % Check if the file is an image (by checking the extension)
        [~, ~, ext] = fileparts(files(i).name);
        % List of common image extensions
        imageExtensions = {'.jpg', '.jpeg', '.png','.tif', '.gif', '.bmp'};
        
        % If the file has a valid image extension, add its full path to the imagePaths array
        if any(strcmpi(ext, imageExtensions))
            % Concatenate the directory path and file name to get the full path
            imagePath = fullfile(directoryPath, files(i).name);
            % Add the full path to the imagePaths array
            imagePaths = [imagePaths; string(imagePath)];
        end
    end
end
function fmapDenoiseAndWrite(inputfilepath, directorytowriteto)
    filesinpath = fgetImagePaths(inputfilepath);
    % going through each image
    for i = 1:length(filesinpath)
        
        % read image, convert to double
        inputimage = im2double(imread(filesinpath(i)));
    
        % map
        result00 = zeros(size(inputimage));
        lambda00 = 0.5;
        for colourindex = 1:size(inputimage,3)
            result00(:,:, colourindex) = bonusfunction(inputimage(:,:,colourindex), lambda00);
        end
    
        % saving to path
        [~, basename00, extension00] = fileparts(filesinpath(i));
        outputfilename = fullfile(directorytowriteto, basename00+extension00);
        imwrite(result00, outputfilename);
    
    end
end
function subdirectories = getSubdirectories(path)
    % List the contents of the directory
    contents = dir(path);

    % Initialize an empty cell array to store subdirectory names
    subdirectories = [];

    % Loop through each item in the directory
    for i = 1:length(contents)

        % Check if the item is a directory and not '.' or '..'
        if contents(i).isdir && ~strcmp(contents(i).name, '.') && ~strcmp(contents(i).name, '..')
            
            % Append the directory name to the cell array
            subdirectories = [subdirectories, string(contents(i).name)];
        end
    end
end
function u = bonusfunction(v, lambda00)
    % initial value 
    u = zeros([size(v,1)+2, size(v,2)+2]);
    
    % 
    pixelvalues = transpose((0:255)/255);
    
    % 
    T = 2.0;
    for iter = 1:3
        for i00 = 2:size(u,1)-1
            for j00 = 2:size(u,2)-1
        
                % a uniform coordinate
                i = i00-1; j = j00-1;
        
                % getting neighbours
                neighbours = [u(j00,i00+1), u(j00-1,i00), u(j00,i00-1), u(j00+1,i00)];
                gibbsprobabilityforeachvalue = repmat(neighbours, [length(pixelvalues), 1]) - repmat(pixelvalues, [1, length(neighbours)]);
                gibbsprobabilityforeachvalue = sum(abs(gibbsprobabilityforeachvalue), 2);
                gibbsprobabilityforeachvalue = exp(-gibbsprobabilityforeachvalue/T);
        
                % calculating square distance
                var00 = (repmat(v(j,i), [length(pixelvalues),1]) - pixelvalues).^2;
                var01 = lambda00*gibbsprobabilityforeachvalue;
                cost00 = var00 + var01;
        
                % finding the minima
                [~, minindex] = min(cost00);
                pixelvaluethathasminimahere = pixelvalues(minindex);
        
                % assigning that value here
                u(j00,i00) = pixelvaluethathasminimahere;
        
            end
        end
        
        % updating boundaries
        u(:,1) = u(2,:);
        u(:, end) = u(:,end-1);
        u(1,:) = u(2, :);
        u(end,:) = u(end-1,:);
    
    end

    % trimming so that the dimensions are appropriate
    u = u(2:end-1, 2:end-1);

end




























































