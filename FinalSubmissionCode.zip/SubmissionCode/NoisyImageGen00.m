%{
===========================================================================
Aim: Produce Noisy Images

===========================================================================
%}

%% Basic SEtup
clc; close all; clear all;

%% Path to original images
directorypath = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/OriginalImages";
pathstoimages = fgetImagePaths(directorypath);

%% Creating For Gaussian Noise - using imnoise
general_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/GaussianNoise/Gaussian_Variance=";
for varvalue = 0.0:0.1:1
    % check if folder exists, if not create
    directoryPath = general_path + string(varvalue);
    
    % Check if the directory exists
    if exist(directoryPath, 'dir') == 7
        disp('Directory exists.');
    else
        % If the directory does not exist, create it
        mkdir(directoryPath);
        disp('Directory created successfully.');
    end


    for i = 1:length(pathstoimages)
        % reading image
        img = imread(pathstoimages(i));
        
        % adding noise 
        noisyimg = imnoise(img, "gaussian", 0, varvalue);
        noisyimg = cast(noisyimg, "like", img);
    
        % plotting
        imshow(noisyimg);

        % constructing title
        [~, baseName, extension00] = fileparts(pathstoimages(i));
        % noiseimgtitle = directoryPath + "/" + baseName+"_GaussianNoise_Var="+string(varvalue)+extension00;
        noiseimgtitle = directoryPath + "/" + baseName + extension00;

        % saving image
        imwrite(noisyimg, noiseimgtitle);

     
    end
end

%% Creating Salt and Pepper Noise - using imnoise
general_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SaltAndPepperNoise/SaltAndPepper_Density=";
for density = 0.0:0.1:1
    % check if folder exists, if not create
    directoryPath = general_path + string(density);
    
    % Check if the directory exists
    if exist(directoryPath, 'dir') == 7
        disp('Directory exists.');
    else
        % If the directory does not exist, create it
        mkdir(directoryPath);
        disp('Directory created successfully.');
    end


    for i = 1:length(pathstoimages)
        % reading image
        img = imread(pathstoimages(i));
        
        % adding noise 
        noisyimg = imnoise(img, "salt & pepper", density);
        noisyimg = cast(noisyimg, "like", img);
    
        % plotting
        imshow(noisyimg);

        % constructing title
        [~, baseName, extension00] = fileparts(pathstoimages(i));
        % noiseimgtitle = directoryPath + "/" + baseName+"_SaltAndPepperNoise_density="+string(density)+extension00;
        noiseimgtitle = directoryPath + "/" + baseName + extension00;

        % saving image
        imwrite(noisyimg, noiseimgtitle);

     
    end
end

%% Creating Speckle Noise - using imnoise
general_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SpeckleNoise/Speckle_Var=";
for varvalues = 0.0:0.1:1
    % check if folder exists, if not create
    directoryPath = general_path + string(varvalues);
    
    % Check if the directory exists
    if exist(directoryPath, 'dir') == 7
        disp('Directory exists.');
    else
        % If the directory does not exist, create it
        mkdir(directoryPath);
        disp('Directory created successfully.');
    end


    for i = 1:length(pathstoimages)
        % reading image
        img = imread(pathstoimages(i));
        
        % adding noise 
        noisyimg = imnoise(img, "speckle", varvalues);
        noisyimg = cast(noisyimg, "like", img);
    
        % plotting
        imshow(noisyimg);

        % constructing title
        [~, baseName, extension00] = fileparts(pathstoimages(i));
        % noiseimgtitle = directoryPath + "/" + baseName+"_SpeckleNoise_var="+string(varvalues)+extension00;
        noiseimgtitle = directoryPath + "/" + baseName + extension00;

        % saving image
        imwrite(noisyimg, noiseimgtitle);

     
    end
end

% %% Creating Poisson Noise - using imnoise
% general_path = "/Users/vrsreeganesh/Desktop/BUClasses/ImageProcessing/Project/Noisyimages/SpeckleNoise/";
% 
% for i = 1:length(pathstoimages)
%     % reading image
%     img = imread(pathstoimages(i));
% 
%     % adding noise 
%     noisyimg = imnoise(img, "poisson");
%     noisyimg = cast(noisyimg, "like", img);
% 
%     % plotting
%     imshow(noisyimg); pause(1)
% 
%     % constructing title
%     [~, baseName, extension00] = fileparts(pathstoimages(i));
%     noiseimgtitle = directoryPath + "/" + baseName+"_PoissonNoise"+extension00;
% 
%     % % saving image
%     % imwrite(noisyimg, noiseimgtitle);
% 
% 
% end







%% Functions
function imagePaths = fgetImagePaths(directoryPath)
    % List all files in the directory
    files = dir(directoryPath);
    
    % Initialize an empty cell array to store image paths
    imagePaths = [];
    
    % Iterate through each file in the directory
    for i = 1:length(files)
        % Check if the file is an image (by checking the extension)
        [~, ~, ext] = fileparts(files(i).name);
        % List of common image extensions
        imageExtensions = {'.jpg', '.jpeg', '.png','.tif', '.gif', '.bmp'};
        
        % If the file has a valid image extension, add its full path to the imagePaths array
        if any(strcmpi(ext, imageExtensions))
            % Concatenate the directory path and file name to get the full path
            imagePath = fullfile(directoryPath, files(i).name);
            % Add the full path to the imagePaths array
            imagePaths = [imagePaths; string(imagePath)];
        end
    end
end